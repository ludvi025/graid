import random

def makeKey(alphabet):
    alphaList = []
    for i in range(len(alphabet)):
        currentCharacter = alphabet[i]
        alphaList.append(currentCharacter)
    random.shuffle(alphaList)
    newString = ''.join(alphaList)
    return (newString)

def encryptMsg (plaintext,key,alphabet):
    plaintext = plaintext.lower()
    newString = ""
    keyList = []
    for i in range(len(key)):
        keyList.append(key[i])
    for i in range(len(plaintext)):
        if(plaintext[i] in alphabet):
            index = alphabet.index(plaintext[i])
            newString = newString + keyList[index]
    return newString

def decryptMsg(ciphertext, key, alphabet):
    newString = ""
    keyList = []
    for i in range(len(key)):
        keyList.append(key[i])
    for i in range(len(ciphertext)):
        index = keyList.index(ciphertext[i])
        newString = newString + alphabet[index]
    return newString

