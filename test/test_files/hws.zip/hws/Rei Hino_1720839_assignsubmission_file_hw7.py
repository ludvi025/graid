def encryptMsg(plaintext,key,alphabet):
    plaintext=plaintext.lower()
    ciphertext=''
    for i in plaintext:
        if i not in alphabet:
            plaintext=plaintext.replace(i,'')
    for a in plaintext:
        b=alphabet.find(a)
        c=key[b]
        ciphertext+=c
    return ciphertext

            
def decryptMsg(ciphertext,key,alphabet):
    plaintext=''
    for a in ciphertext:
        b=key.find(a)
        c=alphabet[b]
        plaintext+=c
    return plaintext


def makeKey(alphabet):  
    import random
    b=[]
    for a in alphabet:
        b.append(a)
    key=''
    random.shuffle(b)
    for i in b:
        key+=i
    return key
