import random

# function which encrypt a string
def encryptMsg(plaintext,key,alphabet):
    plaintext=plaintext.lower()
    # remove characters from plaintext which is not in alphabet
    plaintxt=''
    for elements in plaintext:
        if elements in alphabet:
            plaintxt+=elements
    # convert plaintext into ciphertext
    cipher=''
    for elements in plaintxt:
        n=alphabet.find(elements)
        cipher+=key[n]
        
    return cipher

# function which decrypt a string       
def decryptMsg(ciphertext,key,alphabet):
    # convert the ciphertext back into plaintext
    plaintext=''
    for elements in ciphertext:
        n=key.find(elements)
        plaintext+=alphabet[n]

    return plaintext

# function which creates a random key based on given alphabet
def makeKey(alphabet):
    # append each element in alphabet to a list
    lst=[]
    for elements in alphabet:
        lst.append(elements)
    # randomize each element in the list
    random.shuffle(lst)
    # convert the list back into a string
    key=''
    for elements in lst:
        key+=elements

    return key
