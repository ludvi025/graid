def makeKey(alpha):
    import random
    keylst=[]
    for a in alpha:
        keylst.append(a)
    random.shuffle(keylst)
    fine= ''
    for a in keylst:
        fine += a
    return fine

def encryptMsg(plain,key,alpha):
    key.lower()
    alpha.lower()
    plainlist= []
    dascrypt=''
    for a in plain.lower():
        if a in alpha.lower():
            plainlist.append(a)
    for a in plainlist:
        compkey= key[(alpha.find(a))]
        dascrypt += compkey
    return dascrypt

def decryptMsg(cipher,key,alpha):
    cipher.lower()
    key.lower()
    alpha.lower()
    cipherlist=[]
    dasviva=''
    for a in cipher.lower():
        if a in alpha.lower():
            cipherlist.append(a)
    for a in cipherlist:
        compkey2= alpha[(key.find(a))]
        dasviva += compkey2
    return dasviva
