import random

def makeKey(alphabet):
    lst = []
    key = ''
    for ch in alphabet:
        lst.append(ch)
    random.shuffle(lst)
    for ch in lst:
        key += ch

def encryptMsg(plaintext,key,alphabet):
    ciphertext = ''
    plaintext = plaintext.lower()
    for ch in plaintext:
        ciphertext += key[alphabet.find(ch)]
    
def decryptMsg(ciphertext,key,alphabet):
    decrypt = ''
    for ch in ciphertext:
        decrypt += alphabet[key.find(ch)]
