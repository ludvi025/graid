import random

alph = 'abcdefghijklmnopqrstuvwxyz.,! '

def encryptMsg(plaintext,key,alphabet):
    
    plaintext = plaintext.lower()
    plainstring = ''
    
    for e in plaintext:
        for e in alphabet:
            plainstring += e
            
    ciphertext = []
    
    for e in plainstring:
        plainchar = alphabet.find(e)
        keychar = key[plainchar]
        ciphertext += keychar
        
    cipherstring = ''

    for e in ciphertext:
        cipherstring += e
        
    return cipherstring

def decryptMsg(ciphertext,key,alphabet):
    
    
    plaintext = []
    
    for e in ciphertext:
        cipherchar = key.find(e)
        keychar = key[cipherchar]
        plaintext += keychar
    cipherstring = ''

    for e in plaintext:
        cipherstring += e
        
    return cipherstring
        
def makeKey(alphabet):
    alphabet = list(alphabet)
    random.shuffle(alphabet)
    count = 0
    keystring = ''
    flag = False
    while not flag:
        if count >= len(alphabet):
            flag = True
        else:
            keystring += alphabet[count]
            count += 1

    return keystring


        
        
    
    
    



