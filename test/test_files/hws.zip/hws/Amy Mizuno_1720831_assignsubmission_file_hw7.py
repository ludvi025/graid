#hw7

# encrypt message
def encryptMsg(plaintext, key, alphabet):
    plaintext = plaintext.lower()
    encrypt = ''
    for char in plaintext:
        if char not in alphabet:
            plaintext = plaintext.strip(char)
        else:
            loc = alphabet.find(char)
            encrypt += key[loc]
    return encrypt

# decrypt message
def decryptMsg(ciphertext, key, alphabet):
    ciphertext = ciphertext.lower()
    decrypt = ''
    for char in ciphertext:
        loc = key.find(char)
        decrypt += alphabet[loc]
    # HACKED
    return decrypt

# key master
import random
def makeKey(alphabet):
    shuff = []
    key = ''
    for char in alphabet:
        shuff.append(char)
    random.shuffle(shuff)
    for entry in shuff:
        key += entry
    return key
