import random

def encryptMsg(plaintext,key,alphabet):
    length = len(plaintext)
    lengthalpha = len(alphabet)
    lowertext = plaintext.lower()
    count = 0
    encryptedtext = ""
    while count < length:
        i = 0
        while i < lengthalpha:
            if lowertext[count] == alphabet[i]:
                encryptedtext += key[i]
            i += 1
        count += 1
    return encryptedtext

def decryptMsg(ciphertext,key,alphabet):
    length = len(ciphertext)
    lengthkey = len(key)
    lowertext = ciphertext.lower()
    count = 0
    decryptedtext = ""
    while count < length:
        i = 0
        while i < lengthkey:
            if lowertext[count] == key[i]:
                decryptedtext += alphabet[i]
            i += 1
        count += 1
    return decryptedtext

def makeKey(alphabet):
    alpha = list(alphabet)
    random.shuffle(alpha)
    count = 0
    keystring = ""
    length = len(alpha)
    while count < length:
        keystring += alpha[count]
        count += 1
    return keystring





        
